package com.zapbox.tv

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.net.URL

data class Channel(val name: String, val url: String, val group: String, val logo: String?, val tvgId: String? = null)

object Playlist {
    private val groupRx = Regex("group-title=\"([^\"]*)\"")
    private val idRx = Regex("tvg-id=\"([^\"]*)\"")
    private val logoRx = Regex("tvg-logo=\"([^\"]*)\"")

    fun parseM3u(lines: Sequence<String>): List<Channel> {
        val out = mutableListOf<Channel>()
        var name = ""
        var group = "Allgemein"
        var logo: String? = null
        var tvgId: String? = null
        for (raw in lines) {
            val line = raw.trim()
            if (line.startsWith("#EXTINF")) {
                name = line.substringAfterLast(",").trim()
                group = groupRx.find(line)?.groupValues?.get(1)?.ifBlank { null } ?: "Allgemein"
                logo = logoRx.find(line)?.groupValues?.get(1)
                tvgId = idRx.find(line)?.groupValues?.get(1)?.ifBlank { null }
            } else if (line.isNotEmpty() && !line.startsWith("#")) {
                out += Channel(name.ifBlank { line }, line, group, logo, tvgId)
                name = ""
            }
        }
        return out
    }

    fun xtreamUrl(server: String, user: String, pass: String) =
        "${server.trimEnd('/')}/get.php?username=$user&password=$pass&type=m3u_plus&output=ts"

    suspend fun load(url: String): List<Channel> = withContext(Dispatchers.IO) {
        val c = URL(url).openConnection().apply { connectTimeout = 15000; readTimeout = 30000 }
        c.getInputStream().bufferedReader().useLines { parseM3u(it) }
    }
}
