package com.zapbox.tv

import java.io.File

/** Einfacher lokaler Cache: Playlist und EPG erscheinen beim Start sofort. */
object Cache {
    private fun clean(s: String?) = (s ?: "").replace('\t', ' ').replace('\n', ' ')

    fun saveChannels(dir: File, list: List<Channel>) {
        File(dir, "channels.tsv").bufferedWriter().use { w ->
            for (c in list) {
                w.write(listOf(c.name, c.url, c.group, c.logo, c.tvgId).joinToString("\t") { clean(it) })
                w.newLine()
            }
        }
    }

    fun loadChannels(dir: File): List<Channel> {
        val f = File(dir, "channels.tsv")
        if (!f.exists()) return emptyList()
        return try {
            f.bufferedReader().useLines { lines ->
                lines.map { it.split("\t") }
                    .filter { it.size >= 5 }
                    .map { Channel(it[0], it[1], it[2], it[3].ifEmpty { null }, it[4].ifEmpty { null }) }
                    .toList()
            }
        } catch (e: Exception) {
            emptyList()
        }
    }

    fun saveEpg(dir: File, map: Map<String, List<Program>>) {
        File(dir, "epg.tsv").bufferedWriter().use { w ->
            for ((id, l) in map) {
                for (p in l) {
                    w.write("${clean(id)}\t${p.start}\t${p.end}\t${clean(p.title)}")
                    w.newLine()
                }
            }
        }
    }

    fun loadEpg(dir: File): Map<String, List<Program>> {
        val f = File(dir, "epg.tsv")
        if (!f.exists()) return emptyMap()
        val now = System.currentTimeMillis() / 1000
        return try {
            f.bufferedReader().useLines { lines ->
                lines.map { it.split("\t") }
                    .filter { it.size >= 4 }
                    .map { it[0] to Program(it[3], it[1].toLong(), it[2].toLong()) }
                    .filter { it.second.end > now }
                    .groupBy({ it.first }, { it.second })
            }.mapValues { e -> e.value.sortedBy { it.start } }
        } catch (e: Exception) {
            emptyMap()
        }
    }

    fun clear(dir: File) {
        File(dir, "channels.tsv").delete()
        File(dir, "epg.tsv").delete()
    }
}
