package com.zapbox.tv

import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import android.util.Xml
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.net.URL
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.zip.GZIPInputStream

data class Program(val title: String, val start: Long, val end: Long)

object Epg {
    // Erkennt Xtream-Stream-URLs: http://server/(live/)user/pass/12345(.ts)
    private val rx = Regex("^(https?://[^/]+)/(?:live/)?([^/]+)/([^/]+)/(\\d+)(?:\\.\\w+)?$")

    suspend fun upcoming(streamUrl: String): List<Program> = withContext(Dispatchers.IO) {
        val m = rx.find(streamUrl) ?: return@withContext emptyList()
        val (server, user, pass, id) = m.destructured
        val api = "$server/player_api.php?username=$user&password=$pass" +
            "&action=get_short_epg&stream_id=$id&limit=4"
        val arr = JSONObject(URL(api).readText()).optJSONArray("epg_listings")
            ?: return@withContext emptyList()
        val now = System.currentTimeMillis() / 1000
        (0 until arr.length())
            .map { arr.getJSONObject(it) }
            .map { Program(decode(it.optString("title")), it.optLong("start_timestamp"), it.optLong("stop_timestamp")) }
            .filter { it.end > now }
            .sortedBy { it.start }
    }

    fun xtreamXmltv(server: String, user: String, pass: String) =
        "${server.trimEnd('/')}/xmltv.php?username=$user&password=$pass"

    private fun parseTime(s: String?): Long {
        if (s == null) return 0L
        for (pattern in listOf("yyyyMMddHHmmss Z", "yyyyMMddHHmmss")) {
            try {
                return SimpleDateFormat(pattern, Locale.US).parse(s.trim())!!.time / 1000
            } catch (e: Exception) { }
        }
        return 0L
    }

    /** Liest XMLTV als Stream; behält nur Sendungen der nächsten 6 Stunden für bekannte Sender. */
    suspend fun loadXmltv(url: String, wanted: Set<String>): Map<String, List<Program>> =
        withContext(Dispatchers.IO) {
            val now = System.currentTimeMillis() / 1000
            val limit = now + 6 * 3600
            val raw = URL(url).openStream().buffered()
            val input = if (url.endsWith(".gz")) GZIPInputStream(raw) else raw
            val out = HashMap<String, MutableList<Program>>()
            input.use { ins ->
                val parser = Xml.newPullParser()
                parser.setInput(ins, null)
                var ev = parser.eventType
                var ch: String? = null
                var st = 0L
                var en = 0L
                var title = ""
                while (ev != XmlPullParser.END_DOCUMENT) {
                    if (ev == XmlPullParser.START_TAG) {
                        if (parser.name == "programme") {
                            ch = parser.getAttributeValue(null, "channel")
                            st = parseTime(parser.getAttributeValue(null, "start"))
                            en = parseTime(parser.getAttributeValue(null, "stop"))
                            title = ""
                        } else if (parser.name == "title" && ch != null && title.isEmpty()) {
                            title = parser.nextText()
                        }
                    } else if (ev == XmlPullParser.END_TAG && parser.name == "programme") {
                        val c = ch
                        if (c != null && c in wanted && en > now && st < limit) {
                            out.getOrPut(c) { mutableListOf() }.add(Program(title, st, en))
                        }
                        ch = null
                    }
                    ev = parser.next()
                }
            }
            out.mapValues { e -> e.value.sortedBy { it.start } }
        }

    private fun decode(s: String): String = try {
        String(Base64.decode(s, Base64.DEFAULT), Charsets.UTF_8)
    } catch (e: Exception) {
        s
    }
}
