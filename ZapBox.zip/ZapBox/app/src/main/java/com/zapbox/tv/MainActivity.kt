package com.zapbox.tv

import android.content.Context
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.focusable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.key.*
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.DefaultLoadControl
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import coil.compose.AsyncImage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) {
                Surface(Modifier.fillMaxSize()) { ZapBoxApp() }
            }
        }
    }
}

@Composable
fun ZapBoxApp() {
    val ctx = LocalContext.current
    val store = remember { Store(ctx.getSharedPreferences("zapbox", Context.MODE_PRIVATE)) }
    val scope = rememberCoroutineScope()

    var channels by remember { mutableStateOf<List<Channel>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var playing by remember { mutableStateOf<Pair<List<Channel>, Int>?>(null) }
    var showEpg by remember { mutableStateOf(false) }
    var epg by remember { mutableStateOf<Map<String, List<Program>>>(emptyMap()) }

    var profiles by remember { mutableStateOf(store.profiles()) }
    var profile by remember { mutableStateOf(profiles.firstOrNull { it.name == store.current } ?: profiles.first()) }
    var favorites by remember { mutableStateOf(store.favs(profile.name)) }
    var recents by remember { mutableStateOf(store.recents(profile.name)) }
    var pin by remember { mutableStateOf(store.pin) }
    var locked by remember { mutableStateOf(store.locked) }
    var unlocked by remember { mutableStateOf(false) }

    val dir = ctx.filesDir

    fun load(url: String, xmltv: String, silent: Boolean = false) {
        if (!silent) { loading = true; error = null }
        scope.launch {
            try {
                val fresh = Playlist.load(url)
                if (fresh.isEmpty()) {
                    if (!silent) error = "Keine Sender gefunden"
                } else {
                    channels = fresh
                    store.url = url
                    store.xmltv = xmltv
                    withContext(Dispatchers.IO) { Cache.saveChannels(dir, fresh) }
                }
            } catch (e: Exception) {
                if (!silent) error = "Fehler: ${e.message}"
            }
            loading = false
            if (channels.isNotEmpty() && xmltv.isNotBlank()) {
                try {
                    val map = Epg.loadXmltv(xmltv, channels.mapNotNull { it.tvgId }.toSet())
                    epg = map
                    withContext(Dispatchers.IO) { Cache.saveEpg(dir, map) }
                } catch (e: Exception) { /* EPG optional */ }
            }
        }
    }

    fun switchProfile(p: Profile) {
        profile = p
        store.current = p.name
        favorites = store.favs(p.name)
        recents = store.recents(p.name)
        unlocked = false
    }

    LaunchedEffect(Unit) {
        val url = store.url ?: return@LaunchedEffect
        val cached = withContext(Dispatchers.IO) { Cache.loadChannels(dir) }
        if (cached.isNotEmpty()) {
            channels = cached
            epg = withContext(Dispatchers.IO) { Cache.loadEpg(dir) }
        }
        load(url, store.xmltv, silent = cached.isNotEmpty())
    }

    val visible = remember(channels, locked, unlocked, profile) {
        channels.filter { it.group !in locked || (unlocked && !profile.kids) }
    }

    fun markSeen(url: String) {
        recents = (listOf(url) + recents.filter { it != url }).take(20)
        store.saveRecents(profile.name, recents)
    }

    val p = playing
    when {
        p != null -> PlayerScreen(p.first, p.second, epg, onSeen = { markSeen(it) }) { playing = null }
        showEpg -> EpgScreen(visible, epg, onPlay = { l, i -> markSeen(l[i].url); playing = l to i }) { showEpg = false }
        channels.isEmpty() -> LoginScreen(loading, error) { u, x -> load(u, x) }
        else -> ChannelScreen(
            all = channels, visible = visible, favorites = favorites, recents = recents,
            profiles = profiles, profile = profile, pin = pin, locked = locked, unlocked = unlocked,
            onPlay = { list, i -> markSeen(list[i].url); playing = list to i },
            onToggleFav = { u ->
                favorites = if (u in favorites) favorites - u else favorites + u
                store.saveFavs(profile.name, favorites)
            },
            onSwitch = { switchProfile(it) },
            onAddProfile = { name, kids ->
                val n = name.replace("|", "").replace("\n", "").trim()
                if (n.isNotEmpty() && profiles.none { it.name == n }) {
                    profiles = profiles + Profile(n, kids)
                    store.saveProfiles(profiles)
                }
            },
            onDeleteProfile = { n ->
                profiles = profiles.filter { it.name != n }
                store.saveProfiles(profiles)
            },
            onSetPin = { pin = it; store.pin = it },
            onSetLocked = { locked = it; store.locked = it },
            onUnlock = { unlocked = true },
            onLock = { unlocked = false },
            onOpenEpg = { showEpg = true },
            onRefresh = { store.url?.let { load(it, store.xmltv, true) } },
            onLogout = { store.url = null; Cache.clear(dir); channels = emptyList(); epg = emptyMap() }
        )
    }
}

@Composable
fun LoginScreen(loading: Boolean, error: String?, onLoad: (String, String) -> Unit) {
    var xtream by remember { mutableStateOf(true) }
    var server by remember { mutableStateOf("") }
    var user by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var m3u by remember { mutableStateOf("") }
    var xmltv by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().padding(48.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("ZapBox", style = MaterialTheme.typography.displayMedium)
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { xtream = true }) { Text("Xtream Codes") }
            Button(onClick = { xtream = false }) { Text("M3U-Link") }
        }
        if (xtream) {
            OutlinedTextField(server, { server = it }, label = { Text("Server (http://…)") }, singleLine = true)
            OutlinedTextField(user, { user = it }, label = { Text("Benutzername") }, singleLine = true)
            OutlinedTextField(
                pass, { pass = it }, label = { Text("Passwort") }, singleLine = true,
                visualTransformation = PasswordVisualTransformation()
            )
            Text("Das Programmraster (XMLTV) wird automatisch geladen.")
        } else {
            OutlinedTextField(m3u, { m3u = it }, label = { Text("M3U-URL") }, singleLine = true)
            OutlinedTextField(xmltv, { xmltv = it }, label = { Text("XMLTV-URL (optional)") }, singleLine = true)
        }
        Button(
            enabled = !loading,
            onClick = {
                if (xtream) {
                    val s = server.trim(); val u = user.trim(); val pw = pass.trim()
                    onLoad(Playlist.xtreamUrl(s, u, pw), Epg.xtreamXmltv(s, u, pw))
                } else onLoad(m3u.trim(), xmltv.trim())
            }
        ) { Text(if (loading) "Lade…" else "Laden") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error) }
    }
}

@Composable
fun PinDialog(error: Boolean, onEntered: (String) -> Unit, onDismiss: () -> Unit) {
    var v by remember { mutableStateOf("") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("PIN eingeben") },
        text = {
            Column {
                OutlinedTextField(
                    v, { if (it.length <= 4 && it.all(Char::isDigit)) v = it }, singleLine = true,
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    visualTransformation = PasswordVisualTransformation()
                )
                if (error) Text("Falsche PIN", color = MaterialTheme.colorScheme.error)
            }
        },
        confirmButton = { TextButton(onClick = { onEntered(v); v = "" }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Abbrechen") } }
    )
}

private const val FAV = "★ Favoriten"
private const val RECENT = "⏱ Zuletzt"

@Composable
fun ChannelScreen(
    all: List<Channel>,
    visible: List<Channel>,
    favorites: Set<String>,
    recents: List<String>,
    profiles: List<Profile>,
    profile: Profile,
    pin: String,
    locked: Set<String>,
    unlocked: Boolean,
    onPlay: (List<Channel>, Int) -> Unit,
    onToggleFav: (String) -> Unit,
    onSwitch: (Profile) -> Unit,
    onAddProfile: (String, Boolean) -> Unit,
    onDeleteProfile: (String) -> Unit,
    onSetPin: (String) -> Unit,
    onSetLocked: (Set<String>) -> Unit,
    onUnlock: () -> Unit,
    onLock: () -> Unit,
    onOpenEpg: () -> Unit,
    onRefresh: () -> Unit,
    onLogout: () -> Unit
) {
    var group by remember(profile.name) { mutableStateOf<String?>(null) }
    var query by remember { mutableStateOf("") }
    var dialog by remember { mutableStateOf<String?>(null) }
    var pinAction by remember { mutableStateOf<(() -> Unit)?>(null) }
    var pinError by remember { mutableStateOf(false) }

    val groupsAll = remember(all) { all.map { it.group }.distinct() }
    val shown = remember(visible, group, query, favorites, recents) {
        val base = when (group) {
            null -> visible
            FAV -> visible.filter { it.url in favorites }
            RECENT -> recents.mapNotNull { u -> visible.find { it.url == u } }
            else -> visible.filter { it.group == group }
        }
        base.filter { it.name.contains(query, ignoreCase = true) }
    }

    // Aktion nur nach PIN ausführen (Kinderprofile können nie dauerhaft entsperren)
    fun guard(action: () -> Unit) {
        if (pin.isEmpty() || (unlocked && !profile.kids)) action() else pinAction = action
    }

    pinAction?.let {
        PinDialog(
            error = pinError,
            onDismiss = { pinAction = null; pinError = false },
            onEntered = { entered ->
                if (entered == pin) {
                    val a = pinAction
                    pinAction = null
                    pinError = false
                    onUnlock()
                    a?.invoke()
                } else pinError = true
            }
        )
    }

    if (dialog == "profiles") {
        var newName by remember { mutableStateOf("") }
        var newKids by remember { mutableStateOf(false) }
        AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Profile") },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Fertig") } },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    profiles.forEach { pr ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Button(
                                modifier = Modifier.weight(1f),
                                onClick = {
                                    dialog = null
                                    if (pr.name != profile.name) {
                                        if (profile.kids) guard { onSwitch(pr) } else onSwitch(pr)
                                    }
                                }
                            ) {
                                Text(
                                    pr.name + (if (pr.kids) " [Kinder]" else "") +
                                        (if (pr.name == profile.name) " ✓" else "")
                                )
                            }
                            if (!profile.kids && profiles.size > 1 && pr.name != profile.name) {
                                TextButton(onClick = { onDeleteProfile(pr.name) }) { Text("Löschen") }
                            }
                        }
                    }
                    if (!profile.kids) {
                        OutlinedTextField(newName, { newName = it }, label = { Text("Neues Profil") }, singleLine = true)
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Checkbox(newKids, { newKids = it })
                            Text("Kinderprofil")
                        }
                        Button(onClick = { onAddProfile(newName, newKids); newName = ""; newKids = false }) {
                            Text("Hinzufügen")
                        }
                    }
                }
            }
        )
    }

    if (dialog == "settings") {
        var newPin by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Kindersicherung") },
            confirmButton = { TextButton(onClick = { dialog = null }) { Text("Fertig") } },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        OutlinedTextField(
                            newPin, { if (it.length <= 4 && it.all(Char::isDigit)) newPin = it },
                            label = { Text(if (pin.isEmpty()) "PIN festlegen (4 Ziffern)" else "PIN ändern") },
                            singleLine = true, modifier = Modifier.weight(1f),
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                            visualTransformation = PasswordVisualTransformation()
                        )
                        TextButton(enabled = newPin.length == 4, onClick = { onSetPin(newPin); newPin = "" }) {
                            Text("Speichern")
                        }
                    }
                    if (pin.isEmpty()) Text("Ohne PIN sind gesperrte Kategorien nicht geschützt.")
                    Text("Gesperrte Kategorien:")
                    LazyColumn(Modifier.height(240.dp)) {
                        items(groupsAll) { g ->
                            val toggle = { onSetLocked(if (g in locked) locked - g else locked + g) }
                            Row(Modifier.fillMaxWidth().clickable { toggle() }, verticalAlignment = Alignment.CenterVertically) {
                                Checkbox(g in locked, { toggle() })
                                Text(g)
                            }
                        }
                    }
                }
            }
        )
    }

    Column(Modifier.fillMaxSize().padding(24.dp)) {
        OutlinedTextField(
            query, { query = it }, label = { Text("Suche") },
            singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Row(
            Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedButton(onClick = { dialog = "profiles" }) { Text("Profil: ${profile.name}") }
            OutlinedButton(onClick = onOpenEpg) { Text("Programmführer") }
            OutlinedButton(onClick = onRefresh) { Text("Aktualisieren") }
            if (!profile.kids) {
                OutlinedButton(onClick = { guard { dialog = "settings" } }) { Text("Kindersicherung") }
                if (locked.isNotEmpty() && unlocked) OutlinedButton(onClick = onLock) { Text("Sperren") }
                OutlinedButton(onClick = onLogout) { Text("Playlist wechseln") }
            }
        }
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(vertical = 12.dp)) {
            item { FilterChip(group == null, { group = null }, { Text("Alle") }) }
            item { FilterChip(group == FAV, { group = FAV }, { Text(FAV) }) }
            item { FilterChip(group == RECENT, { group = RECENT }, { Text(RECENT) }) }
            items(groupsAll) { g ->
                val isLocked = g in locked
                when {
                    isLocked && profile.kids -> {}
                    isLocked && !unlocked ->
                        FilterChip(false, { guard { group = g } }, { Text("🔒 $g") })
                    else -> FilterChip(group == g, { group = g }, { Text(g) })
                }
            }
        }
        if (shown.isEmpty()) Text("Hier ist noch nichts.", modifier = Modifier.padding(16.dp))
        LazyColumn {
            itemsIndexed(shown) { i, ch ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    AsyncImage(
                        model = ch.logo, contentDescription = null,
                        modifier = Modifier.padding(start = 8.dp).size(40.dp)
                    )
                    Text(
                        ch.name,
                        style = MaterialTheme.typography.titleMedium,
                        modifier = Modifier.weight(1f).clickable { onPlay(shown, i) }.padding(16.dp)
                    )
                    TextButton(onClick = { onToggleFav(ch.url) }) {
                        Text(if (ch.url in favorites) "★" else "☆")
                    }
                }
            }
        }
    }
}

@Composable
fun EpgScreen(
    channels: List<Channel>,
    epg: Map<String, List<Program>>,
    onPlay: (List<Channel>, Int) -> Unit,
    onBack: () -> Unit
) {
    BackHandler(onBack = onBack)
    val scroll = rememberScrollState()
    val dpPerMin = 4
    val windowMin = 240
    val now = System.currentTimeMillis() / 1000
    val start = now - now % 1800
    val end = start + windowMin * 60
    val fmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }
    val rows = remember(channels, epg) {
        channels.filter { it.tvgId != null && epg.containsKey(it.tvgId) }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Programmführer", style = MaterialTheme.typography.headlineMedium)
        if (rows.isEmpty()) {
            Text(
                "Keine EPG-Daten gefunden. Bei M3U-Playlists brauchst du eine XMLTV-URL, " +
                    "und die Sender brauchen eine tvg-id.",
                modifier = Modifier.padding(16.dp)
            )
            return@Column
        }
        Row(Modifier.padding(start = 180.dp).horizontalScroll(scroll)) {
            for (k in 0 until windowMin / 30) {
                Box(Modifier.width((30 * dpPerMin).dp)) {
                    Text(fmt.format(Date((start + k * 1800L) * 1000)), style = MaterialTheme.typography.labelMedium)
                }
            }
        }
        LazyColumn {
            itemsIndexed(rows) { i, ch ->
                Row(Modifier.fillMaxWidth().height(48.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        ch.name, maxLines = 1,
                        modifier = Modifier.width(180.dp).clickable { onPlay(rows, i) }.padding(end = 8.dp)
                    )
                    Row(Modifier.horizontalScroll(scroll)) {
                        var cursor = start
                        for (pr in epg[ch.tvgId].orEmpty()) {
                            val s = maxOf(pr.start, cursor)
                            val e = minOf(pr.end, end)
                            if (e <= s) continue
                            if (s > cursor) Spacer(Modifier.width(((s - cursor) / 60 * dpPerMin).dp))
                            Box(
                                Modifier.width(((e - s) / 60 * dpPerMin).dp).fillMaxHeight().padding(1.dp)
                                    .background(MaterialTheme.colorScheme.surfaceVariant)
                                    .clickable { onPlay(rows, i) }.padding(4.dp)
                            ) {
                                Text(pr.title, maxLines = 1, style = MaterialTheme.typography.bodySmall)
                            }
                            cursor = e
                        }
                    }
                }
            }
        }
    }
}

@OptIn(UnstableApi::class)
@Composable
fun PlayerScreen(
    list: List<Channel>,
    start: Int,
    epg: Map<String, List<Program>>,
    onSeen: (String) -> Unit,
    onBack: () -> Unit
) {
    val ctx = LocalContext.current
    var index by remember { mutableIntStateOf(start) }
    val player = remember {
        ExoPlayer.Builder(ctx)
            .setLoadControl(
                DefaultLoadControl.Builder()
                    .setBufferDurationsMs(3000, 15000, 500, 1500)
                    .build()
            ).build()
    }
    val focus = remember { FocusRequester() }
    var programs by remember { mutableStateOf<List<Program>>(emptyList()) }
    val timeFmt = remember { SimpleDateFormat("HH:mm", Locale.getDefault()) }

    BackHandler(onBack = onBack)
    LaunchedEffect(index) {
        programs = emptyList()
        delay(400)
        val ch = list[index]
        programs = try { Epg.upcoming(ch.url) } catch (e: Exception) { emptyList() }
        if (programs.isEmpty()) {
            val now = System.currentTimeMillis() / 1000
            programs = ch.tvgId?.let { epg[it] }.orEmpty().filter { it.end > now }
        }
    }
    LaunchedEffect(index) {
        delay(250) // schnelles Zappen: erst nach kurzer Ruhe laden
        player.setMediaItem(MediaItem.fromUri(list[index].url))
        player.prepare()
        player.playWhenReady = true
        onSeen(list[index].url)
    }
    LaunchedEffect(Unit) { focus.requestFocus() }
    DisposableEffect(Unit) { onDispose { player.release() } }

    Box(
        Modifier.fillMaxSize().background(Color.Black)
            .focusRequester(focus).focusable()
            .onKeyEvent { e ->
                if (e.type == KeyEventType.KeyDown) {
                    when (e.key) {
                        Key.DirectionUp, Key.ChannelUp -> { index = (index + 1) % list.size; true }
                        Key.DirectionDown, Key.ChannelDown -> { index = (index - 1 + list.size) % list.size; true }
                        else -> false
                    }
                } else false
            }
    ) {
        AndroidView(
            factory = { PlayerView(it).apply { this.player = player; useController = false } },
            modifier = Modifier.fillMaxSize()
        )
        Text(
            list[index].name,
            color = Color.White,
            modifier = Modifier.align(Alignment.TopStart).padding(24.dp)
                .background(Color(0x99000000)).padding(8.dp)
        )
        if (programs.isNotEmpty()) {
            Column(
                Modifier.align(Alignment.BottomStart).fillMaxWidth()
                    .background(Color(0xB3000000)).padding(24.dp)
            ) {
                programs.take(2).forEachIndexed { i, pr ->
                    val t = "${timeFmt.format(Date(pr.start * 1000))}–${timeFmt.format(Date(pr.end * 1000))}"
                    Text(
                        (if (i == 0) "Jetzt: " else "Danach: ") + "${pr.title} ($t)",
                        color = Color.White,
                        style = if (i == 0) MaterialTheme.typography.titleMedium
                        else MaterialTheme.typography.bodyMedium
                    )
                }
            }
        }
    }
}
