package com.zapbox.tv

import android.content.SharedPreferences

data class Profile(val name: String, val kids: Boolean)

class Store(private val p: SharedPreferences) {
    fun profiles(): List<Profile> {
        val l = p.getString("profiles", "")!!.split("\n").filter { it.isNotBlank() }.map {
            val x = it.split("|")
            Profile(x[0], x.getOrNull(1) == "1")
        }
        return l.ifEmpty { listOf(Profile("Standard", false)) }
    }

    fun saveProfiles(l: List<Profile>) {
        p.edit().putString("profiles", l.joinToString("\n") { "${it.name}|${if (it.kids) 1 else 0}" }).apply()
    }

    var current: String
        get() = p.getString("profile", "Standard")!!
        set(v) { p.edit().putString("profile", v).apply() }

    var pin: String
        get() = p.getString("pin", "")!!
        set(v) { p.edit().putString("pin", v).apply() }

    var locked: Set<String>
        get() = p.getStringSet("locked", emptySet())!!.toSet()
        set(v) { p.edit().putStringSet("locked", v).apply() }

    var url: String?
        get() = p.getString("url", null)
        set(v) { p.edit().apply { if (v == null) remove("url") else putString("url", v) }.apply() }

    var xmltv: String
        get() = p.getString("xmltv", "")!!
        set(v) { p.edit().putString("xmltv", v).apply() }

    fun favs(profile: String): Set<String> = p.getStringSet("fav_$profile", emptySet())!!.toSet()
    fun saveFavs(profile: String, s: Set<String>) { p.edit().putStringSet("fav_$profile", s).apply() }

    fun recents(profile: String): List<String> =
        p.getString("recent_$profile", "")!!.split("\n").filter { it.isNotBlank() }

    fun saveRecents(profile: String, l: List<String>) {
        p.edit().putString("recent_$profile", l.joinToString("\n")).apply()
    }
}
